<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title> 🎵 ShekooMedia 🎵 </title>
<style>
body{font-family:Arial,sans-serif;background:#f7f7f7;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}
.container{text-align:center;background:#fff;padding:40px;border-radius:10px;box-shadow:0px 4px 15px rgba(0,0,0,0.1);max-width:500px}
h1{color:#25F4EE;margin-bottom:10px}p{color:#333;margin-bottom:20px;line-height:1.5}
.login-button{display:inline-block;padding:12px 25px;background-color:#25F4EE;color:#000;font-weight:bold;border-radius:5px;text-decoration:none;font-size:16px;transition:0.3s}
.login-button:hover{background-color:#1cbcd4}
.version{margin-top:20px;color:#666;font-size:14px}
</style>
</head>
<body>
<div class="container">
<h1> 🎵 ShekooMedia 🎵 </h1>
<p>إدارة محتوى TikTok الخاص بك بكفاءة.<br>  🎵 ShekooMedia 🎵 مرحبًا بك في مدير TikTok. هذا التطبيق يساعدك على إدارة وتنظيم محتوى TikTok الخاص بك.<br>ابدأ بإعداد ميزاتك وتفضيلاتك.</p>
<a href="/auth/tiktok" class="login-button">تسجيل الدخول بحساب TikTok</a>
<div class="version">مدير تيك توك الإصدار 1.0.0</div>
</div>
</body>
</html>
