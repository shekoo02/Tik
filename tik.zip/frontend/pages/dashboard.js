import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard() {
    const [videoStats, setVideoStats] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:3000/analytics/123456?access_token=YOUR_TOKEN')
            .then(res => setVideoStats([res.data]));
    }, []);

    return (
        <div>
            <h1>لوحة التحكم</h1>
            {videoStats.map((v, i) => (
                <div key={i}>
                    <p>Views: {v.views}</p>
                    <p>Likes: {v.likes}</p>
                    <p>Comments: {v.comments}</p>
                    <p>Completion Rate: {v.completion_rate}%</p>
                </div>
            ))}
        </div>
    );
}
