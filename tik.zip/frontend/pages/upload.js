import React, { useState } from 'react';
import axios from 'axios';

export default function Upload() {
    const [file, setFile] = useState(null);
    const [title, setTitle] = useState('');

    const handleUpload = () => {
        const formData = new FormData();
        formData.append('videoPath', file);
        formData.append('title', title);
        formData.append('access_token', 'YOUR_TOKEN');

        axios.post('http://localhost:3000/videos/upload', formData)
            .then(res => alert(res.data.message));
    };

    return (
        <div>
            <h1>رفع فيديو</h1>
            <input type="file" onChange={e => setFile(e.target.files[0])} />
            <input type="text" placeholder="عنوان الفيديو" value={title} onChange={e => setTitle(e.target.value)} />
            <button onClick={handleUpload}>رفع الفيديو</button>
        </div>
    );
}
