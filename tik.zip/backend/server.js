const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const videosRoutes = require('./routes/videos');
const analyticsRoutes = require('./routes/analytics');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/auth', authRoutes);
app.use('/videos', videosRoutes);
app.use('/analytics', analyticsRoutes);

app.listen(3000, () => console.log('Server running on port 3000'));
