const express = require('express');
const router = express.Router();

router.get('/:video_id', async (req, res) => {
    const video_id = req.params.video_id;
    const access_token = req.query.access_token;
    // استدعاء TikTok API لجلب البيانات الحقيقية
    res.json({ views: 1200, likes: 100, comments: 10, completion_rate: 78 });
});

module.exports = router;
